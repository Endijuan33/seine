use std::collections::BTreeMap;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use std::thread::{self, JoinHandle};
use std::time::{Duration, Instant};

use anyhow::{anyhow, Result};
use crossbeam_channel::{bounded, Sender, TrySendError};
use crossterm::event::{self, Event};

use super::hashrate_tracker::HashrateTracker;
use super::session::SessionHistory;
use super::stats::{format_hashrate_ui, Stats};
use super::tui::{DeviceHashrate, TuiRenderer, TuiState};
use super::ui::{clear_tui_state, set_tui_state, warn};
use super::{backend_descriptions, backend_display_names, BackendSlot};

const NVIDIA_CURRENT_WINDOW_SECS: f64 = 30.0;
const TUI_RENDER_INTERVAL: Duration = Duration::from_secs(1);
const TUI_QUIT_POLL_INTERVAL: Duration = Duration::from_millis(100);
const TUI_RENDER_SIGNAL_CAPACITY: usize = 8;

static PROMPT_ACTIVE: AtomicBool = AtomicBool::new(false);

pub(super) struct PromptSessionGuard;

impl Drop for PromptSessionGuard {
    fn drop(&mut self) {
        PROMPT_ACTIVE.store(false, Ordering::Release);
    }
}

pub(super) fn begin_prompt_session() -> PromptSessionGuard {
    PROMPT_ACTIVE.store(true, Ordering::Release);
    PromptSessionGuard
}

pub(super) struct TuiDisplay {
    state: TuiState,
    last_render_request: Instant,
    last_state_label: String,
    render_signal: Sender<RenderSignal>,
    render_stop: Arc<AtomicBool>,
    render_worker: Option<JoinHandle<()>>,
    quit_watcher_stop: Arc<AtomicBool>,
    quit_watcher: Option<JoinHandle<()>>,
    hashrate_tracker: HashrateTracker,
    history: Arc<SessionHistory>,
}

#[derive(Debug, Clone, Copy)]
enum RenderSignal {
    RenderNow,
}

pub(super) struct RoundUiView<'a> {
    pub backends: &'a [BackendSlot],
    pub round_backend_hashes: &'a BTreeMap<u64, u64>,
    pub round_start: Instant,
    pub height: &'a str,
    pub network_hashrate: &'a str,
    pub epoch: u64,
    pub state_label: &'a str,
}

impl TuiDisplay {
    fn new(
        tui_state: TuiState,
        shutdown: Arc<AtomicBool>,
        history: Arc<SessionHistory>,
    ) -> Result<Self> {
        let (render_signal, render_stop, render_worker) =
            spawn_tui_render_worker(Arc::clone(&tui_state), Arc::clone(&shutdown))?;
        let (quit_watcher_stop, quit_watcher) =
            spawn_tui_quit_watcher(shutdown, Arc::clone(&tui_state), render_signal.clone());
        let display = Self {
            state: tui_state,
            last_render_request: Instant::now() - TUI_RENDER_INTERVAL,
            last_state_label: String::new(),
            render_signal,
            render_stop,
            render_worker: Some(render_worker),
            quit_watcher_stop,
            quit_watcher: Some(quit_watcher),
            hashrate_tracker: history.take_hashrate_tracker(),
            history,
        };
        display.request_render();
        Ok(display)
    }

    fn update(&mut self, stats: &Stats, view: RoundUiView<'_>) {
        let state_changed = self.last_state_label != view.state_label;
        if !state_changed && self.last_render_request.elapsed() < TUI_RENDER_INTERVAL {
            return;
        }

        let snapshot = stats.snapshot();
        let paused = should_zero_current_hashrate(view.state_label);
        self.hashrate_tracker.set_paused(paused);

        // Record sample in the sliding-window tracker
        self.hashrate_tracker
            .record(snapshot.hashes, view.round_start, view.round_backend_hashes);
        let current_window_secs = current_hashrate_window_overrides(view.backends);
        let rates = self
            .hashrate_tracker
            .rates_with_current_windows(&current_window_secs);

        // Build per-device hashrate display data
        let display_names = backend_display_names(view.backends);
        let mut device_hashrates = Vec::with_capacity(view.backends.len());
        for slot in view.backends {
            let id = slot.id;
            let current_rate = rates.current_per_device.get(&id).copied().unwrap_or(0.0);
            let avg_rate = rates.average_per_device.get(&id).copied().unwrap_or(0.0);
            let name = display_names
                .get(&id)
                .cloned()
                .unwrap_or_else(|| slot.backend.name().to_string());
            device_hashrates.push(DeviceHashrate {
                name,
                current: format_hashrate_ui(current_rate),
                average: format_hashrate_ui(avg_rate),
            });
        }

        if let Ok(mut s) = self.state.lock() {
            s.height = view.height.to_string();
            s.network_hashrate = view.network_hashrate.to_string();
            s.epoch = view.epoch;
            s.state = view.state_label.to_string();
            s.round_hashrate = format_hashrate_ui(rates.current_total);
            s.avg_hashrate = format_hashrate_ui(rates.average_total);
            s.total_hashes = snapshot.hashes;
            s.templates = snapshot.templates;
            s.submitted = snapshot.submitted;
            s.stale_shares = snapshot.stale_shares;
            s.accepted = snapshot.accepted;
            s.share_retries = snapshot.share_retries;
            s.device_hashrates = device_hashrates;
            s.backends_desc = backend_descriptions(view.backends);
        }

        self.request_render();
        self.last_render_request = Instant::now();
        self.last_state_label = view.state_label.to_string();
    }

    pub(super) fn mark_block_found(&mut self) {
        if let Ok(mut s) = self.state.lock() {
            let elapsed = s.started_at.elapsed().as_secs();
            s.push_block_found_tick(elapsed);
        }
        self.request_render();
    }

    fn render_now(&mut self) {
        self.request_render();
        self.last_render_request = Instant::now();
    }

    fn set_state_and_render(&mut self, state_label: &str) {
        let paused = should_zero_current_hashrate(state_label);
        self.hashrate_tracker.set_paused(paused);
        if let Ok(mut s) = self.state.lock() {
            s.state = state_label.to_string();
            if paused {
                let zero = format_hashrate_ui(0.0);
                s.round_hashrate = zero.clone();
                for device in &mut s.device_hashrates {
                    device.current = zero.clone();
                }
            }
        }
        self.last_state_label = state_label.to_string();
        self.render_now();
    }

    fn request_render(&self) {
        match self.render_signal.try_send(RenderSignal::RenderNow) {
            Ok(()) => {}
            Err(TrySendError::Full(_)) => {}
            Err(TrySendError::Disconnected(_)) => {}
        }
    }
}

fn should_zero_current_hashrate(state_label: &str) -> bool {
    matches!(
        state_label,
        "wallet-required"
            | "wallet-password-required"
            | "daemon-syncing"
            | "daemon-unavailable"
            | "invalid-address"
    )
}

fn current_hashrate_window_overrides(backends: &[BackendSlot]) -> BTreeMap<u64, f64> {
    let mut overrides = BTreeMap::new();
    for slot in backends {
        if let Some(window_secs) = current_hashrate_window_secs_for_backend(slot.backend.name()) {
            // NVIDIA deep-launch batches complete in bursts, so a longer
            // current-rate window keeps the TUI from oscillating between
            // adjacent samples while leaving other backends responsive.
            overrides.insert(slot.id, window_secs);
        }
    }
    overrides
}

fn current_hashrate_window_secs_for_backend(backend_name: &str) -> Option<f64> {
    match backend_name {
        "nvidia" => Some(NVIDIA_CURRENT_WINDOW_SECS),
        _ => None,
    }
}

impl Drop for TuiDisplay {
    fn drop(&mut self) {
        self.render_stop.store(true, Ordering::SeqCst);
        let _ = self.render_signal.try_send(RenderSignal::RenderNow);
        if let Some(handle) = self.render_worker.take() {
            let _ = handle.join();
        }

        self.quit_watcher_stop.store(true, Ordering::SeqCst);
        if let Some(handle) = self.quit_watcher.take() {
            let _ = handle.join();
        }
        clear_tui_state(&self.state);
        let mut tracker = std::mem::replace(&mut self.hashrate_tracker, HashrateTracker::new());
        tracker.pause_for_restart();
        self.history.save_hashrate_tracker(tracker);
    }
}

pub(super) fn init_tui_display(
    tui_state: Option<TuiState>,
    shutdown: Arc<AtomicBool>,
    history: Arc<SessionHistory>,
) -> Option<TuiDisplay> {
    let state = tui_state?;
    match TuiDisplay::new(Arc::clone(&state), shutdown, history) {
        Ok(display) => {
            set_tui_state(state);
            Some(display)
        }
        Err(err) => {
            warn(
                "TUI",
                format!("disabled after init failure; continuing in plain mode ({err:#})"),
            );
            None
        }
    }
}

pub(super) fn update_tui(tui: &mut Option<TuiDisplay>, stats: &Stats, view: RoundUiView<'_>) {
    if let Some(display) = tui.as_mut() {
        display.update(stats, view);
    }
}

pub(super) fn render_tui_now(tui: &mut Option<TuiDisplay>) {
    if let Some(display) = tui.as_mut() {
        display.render_now();
    }
}

pub(super) fn set_tui_dev_fee_active(tui: &mut Option<TuiDisplay>, active: bool) {
    if let Some(display) = tui.as_mut() {
        if let Ok(mut s) = display.state.lock() {
            s.dev_fee_active = active;
        }
        display.request_render();
    }
}

pub(super) fn set_tui_state_label(tui: &mut Option<TuiDisplay>, state_label: &str) {
    if let Some(display) = tui.as_mut() {
        display.set_state_and_render(state_label);
    }
}

pub(super) fn set_tui_blocktemplate_retrying(tui: &mut Option<TuiDisplay>, retrying: bool) {
    if let Some(display) = tui.as_mut() {
        if let Ok(mut s) = display.state.lock() {
            if retrying {
                if s.blocktemplate_retry_since.is_none() {
                    s.blocktemplate_retry_since = Some(Instant::now());
                }
            } else {
                s.blocktemplate_retry_since = None;
            }
        }
        display.request_render();
    }
}

pub(super) fn set_tui_pending_nvidia(tui: &mut Option<TuiDisplay>, count: u64) {
    if let Some(display) = tui.as_mut() {
        if let Ok(mut s) = display.state.lock() {
            if count > 0 && s.pending_nvidia_since.is_none() {
                s.pending_nvidia_since = Some(Instant::now());
            } else if count == 0 {
                s.pending_nvidia_since = None;
            }
            s.pending_nvidia = count;
        }
    }
}

pub(super) fn set_tui_pool_balance_overview(
    tui: &mut Option<TuiDisplay>,
    address: &str,
    pending: &str,
    paid: &str,
) {
    if let Some(display) = tui.as_mut() {
        if let Ok(mut s) = display.state.lock() {
            s.pool_address = address.to_string();
            s.pool_pending = pending.to_string();
            s.pool_paid = paid.to_string();
        }
        display.request_render();
    }
}

pub(super) fn set_tui_wallet_overview(
    tui: &mut Option<TuiDisplay>,
    address: &str,
    pending: &str,
    unlocked: &str,
) {
    if let Some(display) = tui.as_mut() {
        if let Ok(mut s) = display.state.lock() {
            s.wallet_visible = true;
            s.wallet_address = address.to_string();
            s.wallet_pending = pending.to_string();
            s.wallet_unlocked = unlocked.to_string();
        }
        display.request_render();
    }
}

fn spawn_tui_render_worker(
    state: TuiState,
    shutdown: Arc<AtomicBool>,
) -> Result<(Sender<RenderSignal>, Arc<AtomicBool>, JoinHandle<()>)> {
    let (render_signal_tx, render_signal_rx) = bounded(TUI_RENDER_SIGNAL_CAPACITY.max(1));
    let render_stop = Arc::new(AtomicBool::new(false));
    let render_stop_flag = Arc::clone(&render_stop);
    let (ready_tx, ready_rx) = bounded::<Result<()>>(1);

    let render_worker = thread::spawn(move || {
        let mut renderer = match TuiRenderer::new() {
            Ok(renderer) => {
                let _ = ready_tx.send(Ok(()));
                renderer
            }
            Err(err) => {
                let _ = ready_tx.send(Err(anyhow!("TUI renderer init failed: {err}")));
                return;
            }
        };

        if let Ok(locked) = state.lock() {
            let _ = renderer.render(&locked);
        }

        while !render_stop_flag.load(Ordering::Relaxed) && !shutdown.load(Ordering::Relaxed) {
            match render_signal_rx.recv_timeout(Duration::from_millis(100)) {
                Ok(RenderSignal::RenderNow) => {
                    if let Ok(mut locked) = state.lock() {
                        locked.poll_thread_rejection();
                        let _ = renderer.render(&locked);
                    }
                }
                Err(crossbeam_channel::RecvTimeoutError::Timeout) => {
                    if let Ok(mut locked) = state.lock() {
                        if locked.poll_thread_rejection() {
                            let _ = renderer.render(&locked);
                        }
                    }
                }
                Err(crossbeam_channel::RecvTimeoutError::Disconnected) => break,
            }
        }
    });

    match ready_rx.recv() {
        Ok(Ok(())) => Ok((render_signal_tx, render_stop, render_worker)),
        Ok(Err(err)) => {
            render_stop.store(true, Ordering::SeqCst);
            let _ = render_worker.join();
            Err(err)
        }
        Err(_) => {
            render_stop.store(true, Ordering::SeqCst);
            let _ = render_worker.join();
            Err(anyhow!(
                "TUI renderer thread terminated before initialization"
            ))
        }
    }
}

fn spawn_tui_quit_watcher(
    shutdown: Arc<AtomicBool>,
    state: TuiState,
    render_signal: Sender<RenderSignal>,
) -> (Arc<AtomicBool>, JoinHandle<()>) {
    let stop = Arc::new(AtomicBool::new(false));
    let stop_flag = Arc::clone(&stop);
    let handle = thread::spawn(move || {
        while !stop_flag.load(Ordering::Relaxed) && !shutdown.load(Ordering::Relaxed) {
            if PROMPT_ACTIVE.load(Ordering::Acquire) {
                thread::sleep(Duration::from_millis(50));
                continue;
            }
            let has_event = event::poll(TUI_QUIT_POLL_INTERVAL).unwrap_or(false);
            if !has_event {
                continue;
            }
            if let Ok(Event::Key(key)) = event::read() {
                let quit = state
                    .lock()
                    .map(|mut state| state.handle_key(key))
                    .unwrap_or(false);
                let _ = render_signal.try_send(RenderSignal::RenderNow);
                if quit {
                    shutdown.store(true, Ordering::SeqCst);
                    break;
                }
            }
        }
    });
    (stop, handle)
}

#[cfg(test)]
mod tests {
    use super::{current_hashrate_window_secs_for_backend, should_zero_current_hashrate};

    #[test]
    fn zeroes_current_hashrate_for_non_mining_states() {
        for state in [
            "wallet-required",
            "wallet-password-required",
            "daemon-syncing",
            "daemon-unavailable",
            "invalid-address",
        ] {
            assert!(should_zero_current_hashrate(state));
        }
        assert!(!should_zero_current_hashrate("working"));
        assert!(!should_zero_current_hashrate("refresh"));
    }

    #[test]
    fn nvidia_uses_longer_current_hashrate_window() {
        assert_eq!(
            current_hashrate_window_secs_for_backend("nvidia"),
            Some(30.0)
        );
        assert_eq!(current_hashrate_window_secs_for_backend("cpu"), None);
    }
}
