//! Offline experiment: alternate blocks from two independent full-memory hashes.
//! Built only with cpu-research; the miner never selects this implementation.
use super::*;

impl FixedArgon2id {
    /// Interleave two independent hash chains on one OS thread. This doubles
    /// arena memory per thread; it does not change Argon2 parameters or outputs.
    /// Safe mutable borrows require disjoint output buffers and disjoint arenas.
    pub fn research_streaming_pair<const RING: usize, const DEPTH: usize>(
        &self,
        passwords: [&[u8]; 2],
        salts: [&[u8]; 2],
        outputs: [&mut [u8]; 2],
        memories: [&mut [PowBlock]; 2],
    ) -> Result<()> {
        if !CpuKernel::Avx512256Stream.is_supported() {
            return Err(Error::UnsupportedKernel);
        }
        assert!(RING >= 2 && RING.is_power_of_two());
        assert!((1..=8).contains(&DEPTH));
        // Validate both jobs before touching either arena or output.
        for lane in 0..2 {
            verify_inputs(passwords[lane], salts[lane], outputs[lane])?;
            if memories[lane].len() < self.block_count {
                return Err(Error::MemoryTooLittle);
            }
        }
        let [left, right] = memories;
        let mut memories = [
            &mut left[..self.block_count],
            &mut right[..self.block_count],
        ];
        for lane in 0..2 {
            initialize_lane_blocks(
                memories[lane],
                initial_hash(
                    self.requested_memory_kib,
                    ARGON2_T_COST,
                    ARGON2_LANES,
                    passwords[lane],
                    salts[lane],
                    outputs[lane],
                ),
            )?;
        }
        // ISA support and both arena extents were checked above.
        unsafe { self.fill_streaming_pair::<RING, DEPTH>(&mut memories) };
        for lane in 0..2 {
            finalize(memories[lane], outputs[lane])?;
        }
        Ok(())
    }

    #[target_feature(enable = "avx2,avx512f,avx512vl")]
    unsafe fn fill_streaming_pair<const RING: usize, const DEPTH: usize>(
        &self,
        memories: &mut [&mut [PowBlock]; 2],
    ) {
        use std::arch::x86_64::{__m256i, _mm256_load_si256, _mm256_stream_si256, _mm_mfence};
        let mask = RING - 1;
        let mut rings: [Box<[PowBlock; RING]>; 2] =
            std::array::from_fn(|_| Box::new([PowBlock::default(); RING]));
        for lane in 0..2 {
            rings[lane][0] = memories[lane][0];
            rings[lane][1] = memories[lane][1];
        }
        let arenas = [memories[0].as_mut_ptr(), memories[1].as_mut_ptr()];
        let caches = [rings[0].as_mut_ptr(), rings[1].as_mut_ptr()];
        for slice in 0..SYNC_POINTS {
            let first = if slice == 0 { 2 } else { 0 };
            let di = slice < 2;
            let base = slice * self.segment_length;
            for block in first..self.segment_length {
                let cur = base + block;
                if cur & mask == 0 {
                    // Order both arenas' prior streaming writes before loads.
                    _mm_mfence();
                }
                // The next reference prefetched halfway through one chain's
                // compression has the other chain's whole block to arrive.
                for lane in 0..2 {
                    let arena = arenas[lane];
                    let cache = caches[lane];
                    let prev = &*cache.add((cur - 1) & mask);
                    let reference = if di {
                        self.data_independent_ref_indexes[cur]
                    } else {
                        reference_index(cur - 1, prev.0[0])
                    };
                    debug_assert!(reference < cur - 1);
                    let reference_ptr = if cur - reference < RING {
                        cache.add(reference & mask)
                    } else {
                        arena.add(reference)
                    };
                    let dst = cache.add(cur & mask);
                    debug_assert_ne!(dst, reference_ptr);
                    if di {
                        if block + DEPTH < self.segment_length {
                            let ahead = self.data_independent_ref_indexes[cur + DEPTH];
                            if ahead < cur && cur - ahead >= RING {
                                prefetch_pow_block::<ISA_AVX512_256_STREAM>(&*arena.add(ahead));
                            }
                        }
                        avx512_256::compress_into(prev, &*reference_ptr, &mut *dst);
                    } else if block + 1 < self.segment_length {
                        avx512_256::compress_into_mid_prefetch_ring::<RING>(
                            prev,
                            &*reference_ptr,
                            &mut *dst,
                            cur,
                            arena,
                            cache,
                            cur + 1,
                        );
                    } else {
                        avx512_256::compress_into(prev, &*reference_ptr, &mut *dst);
                    }
                    let src = (*dst).0.as_ptr();
                    let output = (*arena.add(cur)).0.as_mut_ptr();
                    for vector in 0..32 {
                        let value = _mm256_load_si256(src.add(vector * 4).cast::<__m256i>());
                        _mm256_stream_si256(output.add(vector * 4).cast::<__m256i>(), value);
                    }
                }
            }
        }
        _mm_mfence();
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use argon2::{Algorithm, Argon2, Params, Version};

    fn parity<const R: usize, const D: usize>(kib: u32) {
        if !CpuKernel::Avx512256Stream.is_supported() {
            return;
        }
        let fixed = FixedArgon2id::with_kernel(kib, CpuKernel::Avx512256Stream).unwrap();
        let salts: [&[u8]; 2] = [b"first-independent-header", b"other-independent-header"];
        let mut guard = PowBlock::default();
        guard.as_mut().fill(0xa5a5_a5a5_a5a5_a5a5);
        let mut left = vec![guard; fixed.block_count() + 2];
        let mut right = left.clone();
        let reference = Argon2::new(
            Algorithm::Argon2id,
            Version::V0x13,
            Params::new(kib, 1, 1, Some(32)).unwrap(),
        );
        for nonces in [[0u64, u64::MAX], [u64::MAX, 12345], [12345, 0]] {
            let passwords = nonces.map(u64::to_le_bytes);
            let mut expected = [[0; 32]; 2];
            for lane in 0..2 {
                reference
                    .hash_password_into(&passwords[lane], salts[lane], &mut expected[lane])
                    .unwrap();
            }
            let mut a = [0; 32];
            let mut b = [0; 32];
            let last = fixed.block_count() + 1;
            fixed
                .research_streaming_pair::<R, D>(
                    [&passwords[0], &passwords[1]],
                    salts,
                    [&mut a, &mut b],
                    [&mut left[1..last], &mut right[1..last]],
                )
                .unwrap();
            assert_eq!([a, b], expected, "kib={kib},ring={R},depth={D}");
            for arena in [&left, &right] {
                assert_eq!(arena[0].as_ref(), guard.as_ref());
                assert_eq!(arena[last].as_ref(), guard.as_ref());
            }
        }
    }

    #[test]
    fn paired_streaming_matches_independent_hashes_with_dirty_reuse_and_guards() {
        for kib in [
            8, 12, 15, 16, 31, 32, 33, 63, 64, 65, 255, 256, 260, 1024, 4100,
        ] {
            parity::<64, 3>(kib);
            parity::<8, 2>(kib);
        }
    }

    #[test]
    fn paired_streaming_checks_both_jobs_before_mutation() {
        if !CpuKernel::Avx512256Stream.is_supported() {
            return;
        }
        let fixed = FixedArgon2id::with_kernel(32, CpuKernel::Avx512256Stream).unwrap();
        let mut left = vec![PowBlock::default(); 32];
        let mut right = vec![PowBlock::default(); 31];
        let mut a = [0xa5; 32];
        let mut b = a;
        assert_eq!(
            fixed.research_streaming_pair::<64, 3>(
                [b"a", b"b"],
                [b"header-one", b"header-two"],
                [&mut a, &mut b],
                [&mut left, &mut right],
            ),
            Err(Error::MemoryTooLittle)
        );
        assert_eq!(a, [0xa5; 32]);
        assert!(left
            .iter()
            .all(|block| block.as_ref().iter().all(|word| *word == 0)));
    }
}
