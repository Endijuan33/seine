//! Offline 2x2 ring/depth experiment. Does not alter shipping dispatch.
//! verify [memory_kib] | bench <ring:8|64> <depth:2|3> <workers> <seconds> <warmup_seconds>
#[cfg(all(target_arch = "x86_64", target_os = "linux"))]
mod experiment {
    use argon2::{Algorithm, Argon2, Params, Version};
    use blocknet_pow_kernel::{CpuKernel, FixedArgon2id, PowBlock};
    use serde_json::json;
    use std::sync::{Arc, Barrier};
    use std::time::{Duration, Instant};
    const FULL_KIB: u32 = 2 * 1024 * 1024;
    const SALT: &[u8] = b"streaming-full-size";

    fn reference(kib: u32, nonce: u64) -> [u8; 32] {
        let mut out = [0; 32];
        Argon2::new(
            Algorithm::Argon2id,
            Version::V0x13,
            Params::new(kib, 1, 1, Some(32)).unwrap(),
        )
        .hash_password_into(&nonce.to_le_bytes(), SALT, &mut out)
        .unwrap();
        out
    }
    fn hash<const R: usize, const D: usize>(
        fixed: &FixedArgon2id,
        memory: &mut [PowBlock],
        nonce: u64,
    ) -> [u8; 32] {
        let mut out = [0; 32];
        fixed
            .research_streaming_hash::<R, D>(&nonce.to_le_bytes(), SALT, &mut out, memory)
            .unwrap();
        out
    }
    fn verify(kib: u32) {
        assert!(kib >= 8);
        let expected: Vec<_> = [0, 12345, u64::MAX].map(|n| (n, reference(kib, n))).into();
        let fixed = FixedArgon2id::with_kernel(kib, CpuKernel::Avx512256Stream).unwrap();
        let len = fixed.block_count();
        let mut guard = PowBlock::default();
        guard.as_mut().fill(0xa5a5_a5a5_a5a5_a5a5);
        let mut memory = vec![guard; len + 2];
        for (nonce, wanted) in expected {
            // Each variant reuses the preceding variant's fully dirty arena.
            for (ring, depth) in [(64, 3), (8, 3), (64, 2), (8, 2), (64, 3)] {
                let blocks = &mut memory[1..len + 1];
                let got = match (ring, depth) {
                    (64, 3) => hash::<64, 3>(&fixed, blocks, nonce),
                    (8, 3) => hash::<8, 3>(&fixed, blocks, nonce),
                    (64, 2) => hash::<64, 2>(&fixed, blocks, nonce),
                    (8, 2) => hash::<8, 2>(&fixed, blocks, nonce),
                    _ => unreachable!(),
                };
                assert_eq!(got, wanted, "nonce={nonce},ring={ring},depth={depth}");
                assert_eq!(memory[0].as_ref(), guard.as_ref());
                assert_eq!(memory[len + 1].as_ref(), guard.as_ref());
                println!(
                    "{}",
                    json!({"kind":"parity", "memory_kib":kib, "nonce":nonce,
                    "ring":ring, "depth":depth, "dirty_reuse":true, "guards":true, "passed":true})
                );
            }
        }
    }
    struct Arena {
        ptr: *mut libc::c_void,
        bytes: usize,
    }
    impl Arena {
        fn new() -> Self {
            let bytes = FULL_KIB as usize * 1024;
            unsafe {
                let ptr = libc::mmap(
                    std::ptr::null_mut(),
                    bytes,
                    libc::PROT_READ | libc::PROT_WRITE,
                    libc::MAP_PRIVATE | libc::MAP_ANON,
                    -1,
                    0,
                );
                assert_ne!(ptr, libc::MAP_FAILED);
                let arena = Self { ptr, bytes };
                assert_eq!(libc::madvise(ptr, bytes, libc::MADV_HUGEPAGE), 0);
                assert_eq!(
                    libc::madvise(ptr, bytes, 23),
                    0,
                    "MADV_POPULATE_WRITE unavailable"
                );
                let _ = libc::madvise(ptr, bytes, 25);
                arena
            }
        }
        fn blocks(&mut self) -> &mut [PowBlock] {
            unsafe { std::slice::from_raw_parts_mut(self.ptr.cast(), FULL_KIB as usize) }
        }
    }
    impl Drop for Arena {
        fn drop(&mut self) {
            unsafe {
                libc::munmap(self.ptr, self.bytes);
            }
        }
    }
    fn bench<const R: usize, const D: usize>(workers: usize, seconds: u64, warmup: u64) {
        assert!((1..=64).contains(&workers) && (1..=180).contains(&seconds) && warmup <= 180);
        let wall = Instant::now();
        let expected = reference(FULL_KIB, 0);
        let ready = Arc::new(Barrier::new(workers + 1));
        let start = Arc::new(Barrier::new(workers + 1));
        let finish = Arc::new(Barrier::new(workers + 1));
        let handles: Vec<_> = (0..workers)
            .map(|id| {
                let (ready, start, finish) = (ready.clone(), start.clone(), finish.clone());
                std::thread::spawn(move || {
                    let fixed =
                        FixedArgon2id::with_kernel(FULL_KIB, CpuKernel::Avx512256Stream).unwrap();
                    let mut arena = Arena::new();
                    assert_eq!(hash::<R, D>(&fixed, arena.blocks(), 0), expected);
                    let mut nonce = (id as u64 + 1) << 48;
                    let warming = Instant::now();
                    while warming.elapsed() < Duration::from_secs(warmup) {
                        std::hint::black_box(hash::<R, D>(&fixed, arena.blocks(), nonce));
                        nonce += 1;
                    }
                    ready.wait();
                    start.wait();
                    let hashing = Instant::now();
                    let mut hashes = 0u64;
                    let mut last = [0; 32];
                    while hashing.elapsed() < Duration::from_secs(seconds) {
                        last = hash::<R, D>(&fixed, arena.blocks(), nonce);
                        nonce += 1;
                        hashes += 1;
                    }
                    let elapsed = hashing.elapsed().as_secs_f64();
                    // Keep the arenas resident through the parent's measurement end.
                    finish.wait();
                    json!({"worker":id,"hashes":hashes,"hashing_seconds":elapsed,
                    "last_nonce":nonce-1,"last_hash":last,"first_hash_reference_passed":true})
                })
            })
            .collect();
        ready.wait();
        let backing = std::fs::read_to_string("/proc/self/smaps_rollup").unwrap();
        let hashing = Instant::now();
        start.wait();
        finish.wait();
        let elapsed = hashing.elapsed().as_secs_f64();
        let rows: Vec<_> = handles.into_iter().map(|h| h.join().unwrap()).collect();
        let hashes: u64 = rows.iter().map(|r| r["hashes"].as_u64().unwrap()).sum();
        println!(
            "{}",
            json!({"kind":"kernel_experiment", "schema":1, "ring":R,"depth":D,
            "workers":workers,"memory_kib_per_worker":FULL_KIB,"requested_seconds":seconds,
            "warmup_seconds":warmup,"hashes":hashes,"hashing_seconds":elapsed,
            "hps":hashes as f64/elapsed,"wall_seconds":wall.elapsed().as_secs_f64(),
            "backing_before_measurement":backing,"workers_results":rows,
            "affinity":"OS scheduler", "scope":"CPU-only fixed kernel; excludes setup and warmup; not pool throughput"})
        );
    }
    pub fn main() {
        assert!(CpuKernel::Avx512256Stream.is_supported());
        let args: Vec<_> = std::env::args().skip(1).collect();
        match args[0].as_str() {
            "verify" => verify(args.get(1).map(|s| s.parse().unwrap()).unwrap_or(FULL_KIB)),
            "bench" => {
                assert_eq!(args.len(), 6);
                let workers = args[3].parse().unwrap();
                let seconds = args[4].parse().unwrap();
                let warmup = args[5].parse().unwrap();
                match (args[1].as_str(), args[2].as_str()) {
                    ("64", "3") => bench::<64, 3>(workers, seconds, warmup),
                    ("8", "3") => bench::<8, 3>(workers, seconds, warmup),
                    ("64", "2") => bench::<64, 2>(workers, seconds, warmup),
                    ("8", "2") => bench::<8, 2>(workers, seconds, warmup),
                    _ => panic!("Unsupported ring/depth"),
                }
            }
            _ => panic!("Expected verify or bench"),
        }
    }
}
fn main() {
    #[cfg(all(target_arch = "x86_64", target_os = "linux"))]
    experiment::main();
    #[cfg(not(all(target_arch = "x86_64", target_os = "linux")))]
    panic!("This native experiment requires x86_64 Linux");
}
