//! Offline experiment; no shipping dispatch changes.
//! verify [memory_kib] | bench <single|sequential|paired> <workers> <seconds> <warmup> [ring depth]
#[cfg(all(target_arch = "x86_64", target_os = "linux"))]
mod experiment {
    use argon2::{Algorithm, Argon2, Params, Version};
    use blocknet_pow_kernel::{CpuKernel, FixedArgon2id, PowBlock};
    use serde_json::json;
    use std::sync::{Arc, Barrier};
    use std::time::{Duration, Instant};
    const FULL_KIB: u32 = 2 * 1024 * 1024;
    const SALT: [u8; 92] = [0x42; 92];

    #[derive(Clone, Copy, Debug)]
    enum Mode {
        Single,
        Sequential,
        Paired,
    }
    impl Mode {
        fn arenas(self) -> usize {
            if matches!(self, Self::Single) {
                1
            } else {
                2
            }
        }
    }
    fn reference(kib: u32, nonce: u64) -> [u8; 32] {
        let mut out = [0; 32];
        Argon2::new(
            Algorithm::Argon2id,
            Version::V0x13,
            Params::new(kib, 1, 1, Some(32)).unwrap(),
        )
        .hash_password_into(&nonce.to_le_bytes(), &SALT, &mut out)
        .unwrap();
        out
    }
    struct Arena {
        ptr: *mut libc::c_void,
        bytes: usize,
    }
    impl Arena {
        fn new(kib: u32) -> Self {
            assert!(kib >= 8);
            let bytes = kib as usize * 1024;
            unsafe {
                let ptr = libc::mmap(
                    std::ptr::null_mut(),
                    bytes,
                    libc::PROT_READ | libc::PROT_WRITE,
                    libc::MAP_PRIVATE | libc::MAP_ANON,
                    -1,
                    0,
                );
                assert_ne!(ptr, libc::MAP_FAILED);
                let arena = Self { ptr, bytes };
                assert_eq!(libc::madvise(ptr, bytes, libc::MADV_HUGEPAGE), 0);
                assert_eq!(
                    libc::madvise(ptr, bytes, 23),
                    0,
                    "MADV_POPULATE_WRITE unavailable"
                );
                let _ = libc::madvise(ptr, bytes, 25);
                arena
            }
        }
        fn blocks(&mut self) -> &mut [PowBlock] {
            unsafe { std::slice::from_raw_parts_mut(self.ptr.cast(), self.bytes / 1024) }
        }
    }
    impl Drop for Arena {
        fn drop(&mut self) {
            unsafe {
                libc::munmap(self.ptr, self.bytes);
            }
        }
    }
    fn hash<const RING: usize, const DEPTH: usize>(
        fixed: &FixedArgon2id,
        memory: &mut [Arena],
        nonce: u64,
        mode: Mode,
    ) -> [[u8; 32]; 2] {
        let mut a = [0; 32];
        let mut b = [0; 32];
        let passwords = [nonce.to_le_bytes(), (nonce + 1).to_le_bytes()];
        if matches!(mode, Mode::Paired) {
            let (left, right) = memory.split_at_mut(1);
            fixed
                .research_streaming_pair::<RING, DEPTH>(
                    [&passwords[0], &passwords[1]],
                    [&SALT, &SALT],
                    [&mut a, &mut b],
                    [left[0].blocks(), right[0].blocks()],
                )
                .unwrap();
        } else {
            fixed
                .research_streaming_hash::<RING, DEPTH>(
                    &passwords[0],
                    &SALT,
                    &mut a,
                    memory[0].blocks(),
                )
                .unwrap();
            if matches!(mode, Mode::Sequential) {
                fixed
                    .research_streaming_hash::<RING, DEPTH>(
                        &passwords[1],
                        &SALT,
                        &mut b,
                        memory[1].blocks(),
                    )
                    .unwrap();
            }
        }
        [a, b]
    }
    fn verify<const RING: usize, const DEPTH: usize>(kib: u32) {
        // Compute and release independent reference arenas before the 4 GiB pair.
        let nonces = [0, 12345, u64::MAX - 1];
        let expected = nonces.map(|n| [reference(kib, n), reference(kib, n + 1)]);
        let fixed = FixedArgon2id::with_kernel(kib, CpuKernel::Avx512256Stream).unwrap();
        let mut memory: Vec<_> = (0..2).map(|_| Arena::new(kib)).collect();
        for (nonce, wanted) in nonces.into_iter().zip(expected) {
            for mode in [
                Mode::Sequential,
                Mode::Paired,
                Mode::Sequential,
                Mode::Paired,
            ] {
                assert_eq!(
                    hash::<RING, DEPTH>(&fixed, &mut memory, nonce, mode),
                    wanted
                );
                println!(
                    "{}",
                    json!({"kind":"parity","memory_kib":kib,"nonce":nonce,"ring":RING,"depth":DEPTH,
                    "mode":format!("{mode:?}"),"hashes_checked":2,"dirty_reuse":true,"passed":true})
                );
            }
        }
    }

    fn bench<const RING: usize, const DEPTH: usize>(
        mode: Mode,
        workers: usize,
        seconds: u64,
        warmup: u64,
    ) {
        assert!((1..=64).contains(&workers) && (1..=180).contains(&seconds) && warmup <= 180);
        let wall = Instant::now();
        let expected = [reference(FULL_KIB, 0), reference(FULL_KIB, 1)];
        let ready = Arc::new(Barrier::new(workers + 1));
        let start = Arc::new(Barrier::new(workers + 1));
        let finish = Arc::new(Barrier::new(workers + 1));
        let handles: Vec<_> = (0..workers)
            .map(|id| {
                let (ready, start, finish) = (ready.clone(), start.clone(), finish.clone());
                std::thread::spawn(move || {
                    let fixed =
                        FixedArgon2id::with_kernel(FULL_KIB, CpuKernel::Avx512256Stream).unwrap();
                    let mut memory: Vec<_> =
                        (0..mode.arenas()).map(|_| Arena::new(FULL_KIB)).collect();
                    let check = hash::<RING, DEPTH>(&fixed, &mut memory, 0, mode);
                    assert_eq!(check[..mode.arenas()], expected[..mode.arenas()]);
                    let mut nonce = (id as u64 + 1) << 48;
                    let warming = Instant::now();
                    while warming.elapsed() < Duration::from_secs(warmup) {
                        std::hint::black_box(hash::<RING, DEPTH>(&fixed, &mut memory, nonce, mode));
                        nonce += mode.arenas() as u64;
                    }
                    // Independent ranges preserve nonce uniqueness and repeatability.
                    nonce = (id as u64 + 1) << 48;
                    let mut claims = Vec::with_capacity(seconds as usize * 16);
                    ready.wait();
                    start.wait();
                    let hashing = Instant::now();
                    while hashing.elapsed() < Duration::from_secs(seconds) {
                        let hashes = hash::<RING, DEPTH>(&fixed, &mut memory, nonce, mode);
                        for (offset, output) in hashes.into_iter().take(mode.arenas()).enumerate() {
                            claims.push((nonce + offset as u64, output));
                        }
                        nonce += mode.arenas() as u64;
                    }
                    let elapsed = hashing.elapsed().as_secs_f64();
                    finish.wait(); // Keep every arena resident through global timing.
                    json!({"worker":id,"hashes":claims.len(),"hashing_seconds":elapsed,
                        "first_hash_reference_passed":true,"claims":claims})
                })
            })
            .collect();
        ready.wait();
        let backing = std::fs::read_to_string("/proc/self/smaps_rollup").unwrap();
        let hashing = Instant::now();
        start.wait();
        finish.wait();
        let elapsed = hashing.elapsed().as_secs_f64();
        let rows: Vec<_> = handles.into_iter().map(|h| h.join().unwrap()).collect();
        let hashes: u64 = rows.iter().map(|r| r["hashes"].as_u64().unwrap()).sum();
        println!(
            "{}",
            json!({"kind":"paired_arena_experiment","schema":1,
            "mode":format!("{mode:?}"),"ring":RING,"depth":DEPTH,"workers":workers,"arenas_per_worker":mode.arenas(),
            "memory_kib_per_arena":FULL_KIB,"requested_seconds":seconds,"warmup_seconds":warmup,
            "hashes":hashes,"hashing_seconds":elapsed,"hps_unverified":hashes as f64/elapsed,
            "wall_seconds":wall.elapsed().as_secs_f64(),"backing_before_measurement":backing,
            "workers_results":rows,"header_base":SALT.to_vec(),"affinity":"OS scheduler",
            "scope":"Offline fixed kernel; allocation and warmup excluded; all measured claims retained for independent verification"})
        );
    }
    pub fn main() {
        assert!(CpuKernel::Avx512256Stream.is_supported());
        let args: Vec<_> = std::env::args().skip(1).collect();
        match args.first().map(String::as_str) {
            Some("verify") => {
                assert!(args.len() <= 2);
                let kib = args.get(1).map(|s| s.parse().unwrap()).unwrap_or(FULL_KIB);
                verify::<64, 3>(kib);
                verify::<8, 2>(kib);
            }
            Some("bench") => {
                assert!(args.len() == 5 || args.len() == 7);
                let mode = match args[1].as_str() {
                    "single" => Mode::Single,
                    "sequential" => Mode::Sequential,
                    "paired" => Mode::Paired,
                    _ => panic!("mode must be single, sequential or paired"),
                };
                let workers = args[2].parse().unwrap();
                let seconds = args[3].parse().unwrap();
                let warmup = args[4].parse().unwrap();
                let ring = args.get(5).map(|s| s.parse().unwrap()).unwrap_or(64);
                let depth = args.get(6).map(|s| s.parse().unwrap()).unwrap_or(3);
                match (ring, depth) {
                    (64, 3) => bench::<64, 3>(mode, workers, seconds, warmup),
                    (8, 2) => bench::<8, 2>(mode, workers, seconds, warmup),
                    _ => panic!("supported ring/depth pairs are 64/3 and 8/2"),
                }
            }
            _ => panic!("verify [memory_kib] | bench <single|sequential|paired> <workers> <seconds> <warmup> [ring depth]"),
        }
    }
}

fn main() {
    #[cfg(all(target_arch = "x86_64", target_os = "linux"))]
    experiment::main();
    #[cfg(not(all(target_arch = "x86_64", target_os = "linux")))]
    panic!("This offline experiment requires Linux x86_64");
}
