//! Offline demand-fence screen; no shipping dispatch changes.
//! verify <ring> <depth> [memory_kib] | bench <ring> <depth> <workers> <seconds> <warmup>
#[cfg(all(
    target_arch = "x86_64",
    any(target_os = "linux", target_os = "windows")
))]
mod experiment {
    use argon2::{Algorithm, Argon2, Params, Version};
    use blocknet_pow_kernel::{CpuKernel, FixedArgon2id, PowBlock};
    use serde_json::json;
    use std::sync::{Arc, Barrier};
    use std::time::{Duration, Instant};
    const FULL_KIB: u32 = 2 * 1024 * 1024;
    const SALT: &[u8] = &[0x42; 92];

    fn reference(kib: u32, nonce: u64) -> [u8; 32] {
        let mut out = [0; 32];
        Argon2::new(
            Algorithm::Argon2id,
            Version::V0x13,
            Params::new(kib, 1, 1, Some(32)).unwrap(),
        )
        .hash_password_into(&nonce.to_le_bytes(), SALT, &mut out)
        .unwrap();
        out
    }
    fn hash<const R: usize, const D: usize>(
        fixed: &FixedArgon2id,
        memory: &mut [PowBlock],
        nonce: u64,
    ) -> [u8; 32] {
        let mut out = [0; 32];
        fixed
            .research_streaming_demand_fence_hash::<R, D>(
                &nonce.to_le_bytes(),
                SALT,
                &mut out,
                memory,
            )
            .unwrap();
        out
    }
    fn verify<const R: usize, const D: usize>(kib: u32) {
        assert!(kib >= 8);
        let expected: Vec<_> = [0, 12345, u64::MAX].map(|n| (n, reference(kib, n))).into();
        let fixed = FixedArgon2id::with_kernel(kib, CpuKernel::Avx512256Stream).unwrap();
        let len = fixed.block_count();
        let mut guard = PowBlock::default();
        guard.as_mut().fill(0xa5a5_a5a5_a5a5_a5a5);
        let mut memory = vec![guard; len + 2];
        for (nonce, wanted) in expected {
            for reuse in 0..2 {
                let got = hash::<R, D>(&fixed, &mut memory[1..len + 1], nonce);
                assert_eq!(got, wanted, "nonce={nonce},ring={R},depth={D}");
                assert_eq!(memory[0].as_ref(), guard.as_ref());
                assert_eq!(memory[len + 1].as_ref(), guard.as_ref());
                println!(
                    "{}",
                    json!({"kind":"parity", "memory_kib":kib, "nonce":nonce,
                    "ring":R, "depth":D, "fence_policy":"reference-demand", "dirty_reuse":true, "reuse":reuse,
                    "guards":true, "passed":true})
                );
            }
        }
    }
    struct Arena {
        ptr: *mut libc::c_void,
        bytes: usize,
    }
    impl Arena {
        #[cfg(target_os = "linux")]
        fn new() -> Self {
            let bytes = FULL_KIB as usize * 1024;
            unsafe {
                let ptr = libc::mmap(
                    std::ptr::null_mut(),
                    bytes,
                    libc::PROT_READ | libc::PROT_WRITE,
                    libc::MAP_PRIVATE | libc::MAP_ANON,
                    -1,
                    0,
                );
                assert_ne!(ptr, libc::MAP_FAILED);
                let arena = Self { ptr, bytes };
                assert_eq!(libc::madvise(ptr, bytes, libc::MADV_HUGEPAGE), 0);
                assert_eq!(
                    libc::madvise(ptr, bytes, 23),
                    0,
                    "MADV_POPULATE_WRITE unavailable"
                );
                let _ = libc::madvise(ptr, bytes, 25);
                arena
            }
        }
        #[cfg(target_os = "windows")]
        fn new() -> Self {
            let bytes = FULL_KIB as usize * 1024;
            // No MEM_LARGE_PAGES: every comparison uses ordinary Windows pages.
            let ptr = unsafe { windows::VirtualAlloc(std::ptr::null_mut(), bytes, 0x3000, 0x04) };
            assert!(
                !ptr.is_null(),
                "VirtualAlloc failed: {}",
                std::io::Error::last_os_error()
            );
            assert_eq!(ptr as usize % 64, 0);
            Self { ptr, bytes }
        }
        fn blocks(&mut self) -> &mut [PowBlock] {
            unsafe {
                std::slice::from_raw_parts_mut(
                    self.ptr.cast(),
                    self.bytes / std::mem::size_of::<PowBlock>(),
                )
            }
        }
    }
    impl Drop for Arena {
        fn drop(&mut self) {
            unsafe {
                #[cfg(target_os = "linux")]
                libc::munmap(self.ptr, self.bytes);
                #[cfg(target_os = "windows")]
                windows::VirtualFree(self.ptr, 0, 0x8000);
            }
        }
    }
    #[cfg(target_os = "windows")]
    mod windows {
        use std::ffi::c_void;
        #[repr(C)]
        #[derive(Default)]
        struct MemoryCounters {
            size: u32,
            faults: u32,
            peak_working_set: usize,
            working_set: usize,
            quota_peak_paged: usize,
            quota_paged: usize,
            quota_peak_nonpaged: usize,
            quota_nonpaged: usize,
            pagefile: usize,
            peak_pagefile: usize,
            private_bytes: usize,
        }
        #[link(name = "kernel32")]
        extern "system" {
            pub(super) fn VirtualAlloc(
                address: *mut c_void,
                size: usize,
                kind: u32,
                protection: u32,
            ) -> *mut c_void;
            pub(super) fn VirtualFree(address: *mut c_void, size: usize, kind: u32) -> i32;
            fn GetCurrentProcess() -> *mut c_void;
            fn K32GetProcessMemoryInfo(
                process: *mut c_void,
                counters: *mut MemoryCounters,
                size: u32,
            ) -> i32;
        }
        pub(super) fn observation() -> serde_json::Value {
            let mut counters = MemoryCounters::default();
            counters.size = std::mem::size_of::<MemoryCounters>() as u32;
            assert_eq!(counters.size, 80);
            assert_ne!(
                unsafe {
                    K32GetProcessMemoryInfo(GetCurrentProcess(), &mut counters, counters.size)
                },
                0,
                "GetProcessMemoryInfo failed: {}",
                std::io::Error::last_os_error()
            );
            serde_json::json!({"allocator":"VirtualAlloc","allocation_flags":0x3000,
                "large_pages_requested":false,"working_set_bytes":counters.working_set,
                "private_usage_bytes":counters.private_bytes})
        }
    }
    fn bench<const R: usize, const D: usize>(workers: usize, seconds: u64, warmup: u64) {
        assert!((1..=64).contains(&workers) && (1..=180).contains(&seconds) && warmup <= 180);
        let wall = Instant::now();
        let expected = reference(FULL_KIB, 0);
        let ready = Arc::new(Barrier::new(workers + 1));
        let start = Arc::new(Barrier::new(workers + 1));
        let finish = Arc::new(Barrier::new(workers + 1));
        let handles: Vec<_> = (0..workers)
            .map(|id| {
                let (ready, start, finish) = (ready.clone(), start.clone(), finish.clone());
                std::thread::spawn(move || {
                    let fixed =
                        FixedArgon2id::with_kernel(FULL_KIB, CpuKernel::Avx512256Stream).unwrap();
                    let mut arena = Arena::new();
                    assert_eq!(hash::<R, D>(&fixed, arena.blocks(), 0), expected);
                    let mut nonce = (id as u64 + 1) << 48;
                    let warming = Instant::now();
                    while warming.elapsed() < Duration::from_secs(warmup) {
                        std::hint::black_box(hash::<R, D>(&fixed, arena.blocks(), nonce));
                        nonce += 1;
                    }
                    ready.wait();
                    start.wait();
                    let hashing = Instant::now();
                    nonce = (id as u64 + 1) << 48;
                    let mut claims = Vec::with_capacity(seconds as usize * 16);
                    while hashing.elapsed() < Duration::from_secs(seconds) {
                        let digest = hash::<R, D>(&fixed, arena.blocks(), nonce);
                        claims.push((nonce, digest));
                        nonce += 1;
                    }
                    let elapsed = hashing.elapsed().as_secs_f64();
                    // Keep the arenas resident through the parent's measurement end.
                    finish.wait();
                    json!({"worker":id,"hashes":claims.len(),"hashing_seconds":elapsed,
                    "claims":claims,"first_hash_reference_passed":true})
                })
            })
            .collect();
        ready.wait();
        #[cfg(target_os = "linux")]
        let backing = Some(std::fs::read_to_string("/proc/self/smaps_rollup").unwrap());
        #[cfg(target_os = "windows")]
        let backing: Option<String> = None;
        #[cfg(target_os = "linux")]
        let memory_observation = json!({"allocator":"mmap-MADV_HUGEPAGE"});
        #[cfg(target_os = "windows")]
        let memory_observation = windows::observation();
        let hashing = Instant::now();
        start.wait();
        finish.wait();
        let elapsed = hashing.elapsed().as_secs_f64();
        let rows: Vec<_> = handles.into_iter().map(|h| h.join().unwrap()).collect();
        let hashes: u64 = rows.iter().map(|r| r["hashes"].as_u64().unwrap()).sum();
        println!(
            "{}",
            json!({"kind":"ring_grid_experiment", "schema":1, "ring":R,"depth":D,"fence_policy":"reference-demand",
            "workers":workers,"memory_kib_per_worker":FULL_KIB,"requested_seconds":seconds,
            "warmup_seconds":warmup,"hashes":hashes,"hashing_seconds":elapsed,
            "hps_unverified":hashes as f64/elapsed,"wall_seconds":wall.elapsed().as_secs_f64(),
            "header_base":SALT,"os":std::env::consts::OS,
            "memory_observation":memory_observation,"backing_before_measurement":backing,"workers_results":rows,
            "affinity":"OS scheduler", "scope":"CPU-only fixed kernel; excludes setup and warmup; not pool throughput"})
        );
    }
    pub fn main() {
        assert!(CpuKernel::Avx512256Stream.is_supported());
        let args: Vec<_> = std::env::args().skip(1).collect();
        let ring: usize = args.get(1).expect("ring").parse().unwrap();
        let depth: usize = args.get(2).expect("depth").parse().unwrap();
        macro_rules! dispatch {
            ($function:ident $(, $arg:expr)*) => {
                match (ring, depth) {
                    (2, 2) => $function::<2, 2>($($arg),*),
                    (4, 2) => $function::<4, 2>($($arg),*),
                    (8, 2) => $function::<8, 2>($($arg),*),
                    (16, 2) => $function::<16, 2>($($arg),*),
                    (64, 2) => $function::<64, 2>($($arg),*),
                    (64, 3) => $function::<64, 3>($($arg),*),
                    (64, 4) => $function::<64, 4>($($arg),*),
                    (64, 5) => $function::<64, 5>($($arg),*),
                    (64, 6) => $function::<64, 6>($($arg),*),
                    (8, 3) => $function::<8, 3>($($arg),*),
                    _ => panic!("supported ring/depth: 2/2, 4/2, 8/2, 16/2, 64/2, 64/3, 64/4, 64/5, 64/6, 8/3"),
                }
            }
        }
        match args.first().map(String::as_str) {
            Some("verify") => {
                assert!(args.len() == 3 || args.len() == 4);
                let kib = args.get(3).map(|s| s.parse().unwrap()).unwrap_or(FULL_KIB);
                dispatch!(verify, kib);
            }
            Some("bench") => {
                assert_eq!(args.len(), 6);
                dispatch!(
                    bench,
                    args[3].parse().unwrap(),
                    args[4].parse().unwrap(),
                    args[5].parse().unwrap()
                );
            }
            _ => panic!("verify ring depth [memory_kib] | bench ring depth workers seconds warmup"),
        }
    }
}
fn main() {
    #[cfg(all(
        target_arch = "x86_64",
        any(target_os = "linux", target_os = "windows")
    ))]
    experiment::main();
    #[cfg(not(all(
        target_arch = "x86_64",
        any(target_os = "linux", target_os = "windows")
    )))]
    panic!("This native experiment requires x86_64 Linux or Windows");
}
